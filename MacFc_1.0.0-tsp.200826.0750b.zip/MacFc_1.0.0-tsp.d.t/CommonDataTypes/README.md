This folder contains libraries of data types for common use.
- The data types in the CoreCommonDataTypes library are defined on a high level; i.e., can often not be used for mapping to a data schema language.
- The data types in the ImplementationCommonDataTypes library are defined in detail; i.e., can be used for mapping to a data schema language.

Technology specific data types libraries may be added in future.
